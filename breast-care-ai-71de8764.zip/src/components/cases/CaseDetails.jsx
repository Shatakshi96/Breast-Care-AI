import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  ArrowLeft, 
  User, 
  Activity, 
  Calendar,
  FileText
} from "lucide-react";
import { format } from "date-fns";

export default function CaseDetails({ patient, onBack, onRefresh }) {
  const getPredictionBadge = (prediction, confidence) => {
    const colors = {
      malignant: "bg-red-100 text-red-800 border-red-200",
      benign: "bg-green-100 text-green-800 border-green-200",
      pending: "bg-yellow-100 text-yellow-800 border-yellow-200"
    };

    return (
      <div className="flex items-center gap-2">
        <Badge className={`${colors[prediction]} border`}>
          {prediction}
        </Badge>
        {confidence && (
          <span className="text-sm text-gray-600">
            Confidence: {(confidence * 100).toFixed(1)}%
          </span>
        )}
      </div>
    );
  };

  const tumorFeatures = [
    { key: 'radius_mean', label: 'Mean Radius' },
    { key: 'texture_mean', label: 'Mean Texture' },
    { key: 'perimeter_mean', label: 'Mean Perimeter' },
    { key: 'area_mean', label: 'Mean Area' },
    { key: 'smoothness_mean', label: 'Mean Smoothness' },
    { key: 'compactness_mean', label: 'Mean Compactness' },
    { key: 'concavity_mean', label: 'Mean Concavity' },
    { key: 'concave_points_mean', label: 'Mean Concave Points' },
    { key: 'symmetry_mean', label: 'Mean Symmetry' },
    { key: 'fractal_dimension_mean', label: 'Mean Fractal Dimension' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 p-4 md:p-8">
      <div className="max-w-5xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <Button
            variant="outline"
            size="icon"
            onClick={onBack}
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-2xl md:text-3xl font-bold text-gray-900">
              Patient {patient.patient_id}
            </h1>
            <p className="text-gray-600 mt-1">Detailed case analysis and results</p>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Patient Information */}
          <Card className="shadow-lg bg-white/80 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="w-5 h-5 text-blue-600" />
                Patient Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-medium text-gray-700">Basic Details</h4>
                <div className="space-y-1 text-sm mt-2">
                  <p><span className="font-medium">Patient ID:</span> {patient.patient_id}</p>
                  <p><span className="font-medium">Age:</span> {patient.age}</p>
                  <p><span className="font-medium">Gender:</span> {patient.gender}</p>
                  <p><span className="font-medium">Status:</span> {patient.status}</p>
                </div>
              </div>
              
              <div>
                <h4 className="font-medium text-gray-700">Timeline</h4>
                <div className="space-y-1 text-sm mt-2">
                  <p>
                    <Calendar className="w-4 h-4 inline mr-1" />
                    <span className="font-medium">Diagnosis:</span> {format(new Date(patient.diagnosis_date), "PPP")}
                  </p>
                  <p>
                    <Calendar className="w-4 h-4 inline mr-1" />
                    <span className="font-medium">Created:</span> {format(new Date(patient.created_date), "PPP")}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Prediction Results */}
          <Card className="shadow-lg bg-white/80 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="w-5 h-5 text-blue-600" />
                AI Prediction
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-center">
                {getPredictionBadge(patient.prediction, patient.confidence_score)}
              </div>
              
              {patient.prediction !== 'pending' && (
                <div className="bg-gray-50 rounded-lg p-4">
                  <h4 className="font-medium text-gray-700 mb-2">Interpretation</h4>
                  <p className="text-sm text-gray-600">
                    {patient.prediction === 'malignant' 
                      ? "The AI model indicates characteristics consistent with malignancy. Further evaluation is recommended."
                      : "The AI model indicates characteristics consistent with benign tissue. Regular monitoring is advised."
                    }
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Notes */}
          <Card className="shadow-lg bg-white/80 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-blue-600" />
                Medical Notes
              </CardTitle>
            </CardHeader>
            <CardContent>
              {patient.notes ? (
                <p className="text-sm text-gray-700">{patient.notes}</p>
              ) : (
                <p className="text-sm text-gray-500 italic">No additional notes recorded</p>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Tumor Features */}
        <Card className="shadow-lg bg-white/80 backdrop-blur-sm mt-6">
          <CardHeader>
            <CardTitle>Tumor Feature Analysis</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {tumorFeatures.map((feature) => (
                <div key={feature.key} className="bg-gray-50 rounded-lg p-3">
                  <h4 className="font-medium text-gray-700 text-sm">{feature.label}</h4>
                  <p className="text-lg font-semibold text-gray-900">
                    {patient[feature.key] ? patient[feature.key].toFixed(3) : 'N/A'}
                  </p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}