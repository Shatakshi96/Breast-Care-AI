import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { TrendingUp } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

const COLORS = {
  malignant: '#ef4444',
  benign: '#22c55e',
  pending: '#f59e0b'
};

export default function PredictionChart({ patients, isLoading }) {
  const getPredictionData = () => {
    const counts = {
      malignant: patients.filter(p => p.prediction === 'malignant').length,
      benign: patients.filter(p => p.prediction === 'benign').length,
      pending: patients.filter(p => p.prediction === 'pending').length
    };

    return [
      { name: 'Malignant', value: counts.malignant, color: COLORS.malignant },
      { name: 'Benign', value: counts.benign, color: COLORS.benign },
      { name: 'Pending', value: counts.pending, color: COLORS.pending }
    ];
  };

  const getMonthlyData = () => {
    // Mock monthly data for demo
    return [
      { month: 'Jan', malignant: 4, benign: 12, pending: 2 },
      { month: 'Feb', malignant: 3, benign: 15, pending: 1 },
      { month: 'Mar', malignant: 5, benign: 18, pending: 3 },
      { month: 'Apr', malignant: 2, benign: 20, pending: 1 },
      { month: 'May', malignant: 6, benign: 22, pending: 4 },
      { month: 'Jun', malignant: 3, benign: 25, pending: 2 }
    ];
  };

  if (isLoading) {
    return (
      <Card className="shadow-lg bg-white/80 backdrop-blur-sm">
        <CardHeader>
          <CardTitle>Prediction Overview</CardTitle>
        </CardHeader>
        <CardContent>
          <Skeleton className="h-64 w-full" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="shadow-lg bg-white/80 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-blue-600" />
          Prediction Overview
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <h3 className="text-sm font-medium text-gray-600 mb-4">Current Distribution</h3>
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie
                  data={getPredictionData()}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  dataKey="value"
                  label={({ name, value }) => `${name}: ${value}`}
                >
                  {getPredictionData().map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
          
          <div>
            <h3 className="text-sm font-medium text-gray-600 mb-4">Monthly Trends</h3>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={getMonthlyData()}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="benign" stackId="a" fill={COLORS.benign} />
                <Bar dataKey="malignant" stackId="a" fill={COLORS.malignant} />
                <Bar dataKey="pending" stackId="a" fill={COLORS.pending} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}