import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { FileText, Eye, RefreshCw } from "lucide-react";
import { format } from "date-fns";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Skeleton } from "@/components/ui/skeleton";

export default function RecentCases({ patients, isLoading, onRefresh }) {
  const recentPatients = patients.slice(0, 5);

  const getPredictionBadge = (prediction, confidence) => {
    const colors = {
      malignant: "bg-red-100 text-red-800 border-red-200",
      benign: "bg-green-100 text-green-800 border-green-200",
      pending: "bg-yellow-100 text-yellow-800 border-yellow-200"
    };

    return (
      <div className="flex items-center gap-2">
        <Badge className={`${colors[prediction]} border text-xs`}>
          {prediction}
        </Badge>
        {confidence && (
          <span className="text-xs text-gray-500">
            {(confidence * 100).toFixed(1)}%
          </span>
        )}
      </div>
    );
  };

  return (
    <Card className="shadow-lg bg-white/80 backdrop-blur-sm">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-blue-600" />
            Recent Cases
          </CardTitle>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={onRefresh}>
              <RefreshCw className="w-4 h-4" />
            </Button>
            <Link to={createPageUrl("Cases")}>
              <Button variant="outline" size="sm">
                View All
              </Button>
            </Link>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-4">
            {Array(3).fill(0).map((_, i) => (
              <div key={i} className="flex items-center justify-between p-3 border rounded-lg">
                <div className="space-y-2">
                  <Skeleton className="h-4 w-24" />
                  <Skeleton className="h-3 w-32" />
                </div>
                <Skeleton className="h-6 w-16" />
              </div>
            ))}
          </div>
        ) : recentPatients.length === 0 ? (
          <div className="text-center py-8">
            <FileText className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500 mb-2">No cases yet</p>
            <Link to={createPageUrl("Analysis")}>
              <Button className="bg-blue-600 hover:bg-blue-700">
                Start First Analysis
              </Button>
            </Link>
          </div>
        ) : (
          <div className="space-y-3">
            {recentPatients.map((patient) => (
              <div 
                key={patient.id}
                className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50 transition-colors"
              >
                <div>
                  <h4 className="font-medium">Patient {patient.patient_id}</h4>
                  <p className="text-sm text-gray-500">
                    Age {patient.age} • {format(new Date(patient.diagnosis_date), "MMM d, yyyy")}
                  </p>
                </div>
                
                <div className="flex items-center gap-3">
                  {getPredictionBadge(patient.prediction, patient.confidence_score)}
                  <Button variant="ghost" size="icon">
                    <Eye className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}