import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  ArrowLeft, 
  CheckCircle, 
  AlertTriangle, 
  Clock,
  Save,
  Brain
} from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function PredictionResults({ 
  patientData, 
  prediction, 
  isProcessing, 
  onSave, 
  onBack 
}) {
  if (isProcessing) {
    return (
      <Card className="shadow-lg bg-white/80 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="w-5 h-5 text-blue-600" />
            AI Analysis in Progress
          </CardTitle>
        </CardHeader>
        <CardContent className="text-center py-12">
          <div className="w-16 h-16 mx-auto mb-6 bg-blue-100 rounded-full flex items-center justify-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          </div>
          <h3 className="text-lg font-semibold mb-2">Analyzing Tumor Features</h3>
          <p className="text-gray-600 mb-6">
            Our AI model is processing the tumor characteristics to provide an accurate prediction.
          </p>
          <div className="space-y-2">
            <Skeleton className="h-4 w-3/4 mx-auto" />
            <Skeleton className="h-4 w-1/2 mx-auto" />
            <Skeleton className="h-4 w-2/3 mx-auto" />
          </div>
        </CardContent>
      </Card>
    );
  }

  const getPredictionIcon = (pred) => {
    switch (pred) {
      case 'malignant':
        return <AlertTriangle className="w-6 h-6 text-red-500" />;
      case 'benign':
        return <CheckCircle className="w-6 h-6 text-green-500" />;
      default:
        return <Clock className="w-6 h-6 text-yellow-500" />;
    }
  };

  const getPredictionColor = (pred) => {
    switch (pred) {
      case 'malignant':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'benign':
        return 'bg-green-100 text-green-800 border-green-200';
      default:
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
    }
  };

  return (
    <div className="space-y-6">
      <Card className="shadow-lg bg-white/80 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="w-5 h-5 text-blue-600" />
            AI Analysis Results
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <div className="w-20 h-20 mx-auto mb-6 bg-gray-100 rounded-full flex items-center justify-center">
              {getPredictionIcon(prediction?.prediction)}
            </div>
            
            <h2 className="text-2xl font-bold mb-2">
              Prediction: {prediction?.prediction?.charAt(0).toUpperCase() + prediction?.prediction?.slice(1)}
            </h2>
            
            <Badge className={`${getPredictionColor(prediction?.prediction)} border text-lg px-4 py-2 mb-4`}>
              Confidence: {(prediction?.confidence_score * 100).toFixed(1)}%
            </Badge>
            
            <div className="text-gray-600 max-w-2xl mx-auto">
              {prediction?.prediction === 'malignant' ? (
                <p>The AI model indicates a high probability of malignancy. Please consult with an oncologist for further evaluation and treatment planning.</p>
              ) : (
                <p>The AI model indicates the tumor is likely benign. Continue with regular monitoring as recommended by your healthcare provider.</p>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="shadow-lg bg-white/80 backdrop-blur-sm">
        <CardHeader>
          <CardTitle>Patient Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <h4 className="font-semibold text-gray-700">Patient Details</h4>
              <div className="space-y-1 text-sm">
                <p><span className="font-medium">ID:</span> {patientData.patient_id}</p>
                <p><span className="font-medium">Age:</span> {patientData.age}</p>
                <p><span className="font-medium">Gender:</span> {patientData.gender}</p>
                <p><span className="font-medium">Date:</span> {patientData.diagnosis_date}</p>
              </div>
            </div>
            
            <div>
              <h4 className="font-semibold text-gray-700">Key Features</h4>
              <div className="space-y-1 text-sm">
                {prediction?.features_analysis?.high_risk_features && (
                  <div>
                    <span className="font-medium text-red-600">High Risk:</span>
                    <p className="text-red-600">
                      {prediction.features_analysis.high_risk_features.join(', ')}
                    </p>
                  </div>
                )}
                {prediction?.features_analysis?.low_risk_features && (
                  <div>
                    <span className="font-medium text-green-600">Low Risk:</span>
                    <p className="text-green-600">
                      {prediction.features_analysis.low_risk_features.join(', ')}
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-between">
        <Button variant="outline" onClick={onBack}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Features
        </Button>
        <Button onClick={onSave} className="bg-green-600 hover:bg-green-700">
          <Save className="w-4 h-4 mr-2" />
          Save Case
        </Button>
      </div>
    </div>
  );
}