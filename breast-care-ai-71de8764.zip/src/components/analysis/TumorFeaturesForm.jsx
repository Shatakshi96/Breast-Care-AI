import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowLeft, Activity, ArrowRight } from "lucide-react";

const tumorFeatures = [
  { key: 'radius_mean', label: 'Mean Radius', description: 'Mean of distances from center to points on the perimeter', unit: 'μm' },
  { key: 'texture_mean', label: 'Mean Texture', description: 'Standard deviation of gray-scale values', unit: '' },
  { key: 'perimeter_mean', label: 'Mean Perimeter', description: 'Mean size of the core tumor', unit: 'μm' },
  { key: 'area_mean', label: 'Mean Area', description: 'Mean area of the core tumor', unit: 'μm²' },
  { key: 'smoothness_mean', label: 'Mean Smoothness', description: 'Mean of local variation in radius lengths', unit: '' },
  { key: 'compactness_mean', label: 'Mean Compactness', description: 'Mean of (perimeter² / area - 1.0)', unit: '' },
  { key: 'concavity_mean', label: 'Mean Concavity', description: 'Mean of severity of concave portions', unit: '' },
  { key: 'concave_points_mean', label: 'Mean Concave Points', description: 'Mean number of concave portions', unit: '' },
  { key: 'symmetry_mean', label: 'Mean Symmetry', description: 'Mean symmetry of the tumor', unit: '' },
  { key: 'fractal_dimension_mean', label: 'Mean Fractal Dimension', description: 'Mean fractal dimension ("coastline approximation" - 1)', unit: '' }
];

export default function TumorFeaturesForm({ onSubmit, onBack, initialData = {} }) {
  const [formData, setFormData] = useState(
    tumorFeatures.reduce((acc, feature) => {
      acc[feature.key] = initialData[feature.key] || "";
      return acc;
    }, {})
  );

  const handleSubmit = (e) => {
    e.preventDefault();
    const processedData = {};
    
    Object.keys(formData).forEach(key => {
      if (formData[key]) {
        processedData[key] = parseFloat(formData[key]);
      }
    });
    
    onSubmit(processedData);
  };

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <Card className="shadow-lg bg-white/80 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Activity className="w-5 h-5 text-blue-600" />
          Tumor Features Analysis
        </CardTitle>
        <p className="text-sm text-gray-600">
          Enter the measured values from the fine needle aspirate (FNA) analysis
        </p>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            {tumorFeatures.map((feature) => (
              <div key={feature.key} className="space-y-2">
                <Label htmlFor={feature.key} className="text-sm font-medium">
                  {feature.label} {feature.unit && `(${feature.unit})`}
                </Label>
                <Input
                  id={feature.key}
                  type="number"
                  step="0.001"
                  min="0"
                  value={formData[feature.key]}
                  onChange={(e) => handleChange(feature.key, e.target.value)}
                  placeholder="0.000"
                />
                <p className="text-xs text-gray-500">{feature.description}</p>
              </div>
            ))}
          </div>
          
          <div className="flex justify-between pt-6">
            <Button type="button" variant="outline" onClick={onBack}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Patient Info
            </Button>
            <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
              <ArrowRight className="w-4 h-4 mr-2" />
              Analyze Tumor
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}