import React, { useState, useEffect } from "react";
import { Patient } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  Users, 
  TrendingUp, 
  AlertTriangle, 
  CheckCircle, 
  Clock,
  Plus,
  Activity
} from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

import StatsCard from "../components/dashboard/StatsCard";
import RecentCases from "../components/dashboard/RecentCases";
import PredictionChart from "../components/dashboard/PredictionChart";

export default function Dashboard() {
  const [patients, setPatients] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadPatients();
  }, []);

  const loadPatients = async () => {
    setIsLoading(true);
    try {
      const data = await Patient.list("-created_date");
      setPatients(data);
    } catch (error) {
      console.error("Error loading patients:", error);
    }
    setIsLoading(false);
  };

  const getStats = () => {
    const total = patients.length;
    const malignant = patients.filter(p => p.prediction === 'malignant').length;
    const benign = patients.filter(p => p.prediction === 'benign').length;
    const pending = patients.filter(p => p.prediction === 'pending').length;
    
    return { total, malignant, benign, pending };
  };

  const { total, malignant, benign, pending } = getStats();

  return (
    <div className="p-4 md:p-8 bg-gradient-to-br from-blue-50 to-indigo-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Medical Dashboard</h1>
            <p className="text-gray-600">Breast tumor analysis and patient management</p>
          </div>
          <Link to={createPageUrl("Analysis")}>
            <Button className="bg-blue-600 hover:bg-blue-700 shadow-lg">
              <Plus className="w-4 h-4 mr-2" />
              New Analysis
            </Button>
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatsCard
            title="Total Cases"
            value={total}
            icon={Users}
            bgColor="bg-blue-500"
            textColor="text-blue-600"
            change="+12%"
          />
          <StatsCard
            title="Malignant"
            value={malignant}
            icon={AlertTriangle}
            bgColor="bg-red-500"
            textColor="text-red-600"
            change="-5%"
          />
          <StatsCard
            title="Benign"
            value={benign}
            icon={CheckCircle}
            bgColor="bg-green-500"
            textColor="text-green-600"
            change="+8%"
          />
          <StatsCard
            title="Pending"
            value={pending}
            icon={Clock}
            bgColor="bg-yellow-500"
            textColor="text-yellow-600"
            change="+3"
          />
        </div>

        <div className="grid lg:grid-cols-3 gap-6 mb-8">
          <div className="lg:col-span-2">
            <PredictionChart patients={patients} isLoading={isLoading} />
          </div>
          <div>
            <Card className="shadow-lg bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="w-5 h-5 text-blue-600" />
                  Accuracy Metrics
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Model Accuracy</span>
                    <Badge className="bg-green-100 text-green-800">94.7%</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Precision</span>
                    <Badge className="bg-blue-100 text-blue-800">92.3%</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Recall</span>
                    <Badge className="bg-purple-100 text-purple-800">96.1%</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">F1-Score</span>
                    <Badge className="bg-indigo-100 text-indigo-800">94.1%</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        <RecentCases patients={patients} isLoading={isLoading} onRefresh={loadPatients} />
      </div>
    </div>
  );
}