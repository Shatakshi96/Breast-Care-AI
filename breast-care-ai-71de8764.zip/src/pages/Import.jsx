import React, { useState } from "react";
import { UploadFile, ExtractDataFromUploadedFile } from "@/api/integrations";
import { Patient } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { ArrowLeft, CheckCircle, Database, FileUp, Loader2, Table } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Table as UiTable, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

const WISCONSIN_DATASET_SCHEMA = {
  "type": "object",
  "properties": {
    "id": { "type": "number" },
    "diagnosis": { "type": "string" },
    "radius_mean": { "type": "number" },
    "texture_mean": { "type": "number" },
    "perimeter_mean": { "type": "number" },
    "area_mean": { "type": "number" },
    "smoothness_mean": { "type": "number" },
    "compactness_mean": { "type": "number" },
    "concavity_mean": { "type": "number" },
    "concave points_mean": { "type": "number" },
    "symmetry_mean": { "type": "number" },
    "fractal_dimension_mean": { "type": "number" }
  }
};

export default function ImportPage() {
  const navigate = useNavigate();
  const [file, setFile] = useState(null);
  const [status, setStatus] = useState('idle'); // idle, processing, preview, importing, success
  const [error, setError] = useState(null);
  const [extractedData, setExtractedData] = useState([]);

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile && selectedFile.type === 'text/csv') {
      setFile(selectedFile);
      setError(null);
    } else {
      setError("Please select a valid CSV file.");
      setFile(null);
    }
  };

  const handleProcessFile = async () => {
    if (!file) return;

    setStatus('processing');
    setError(null);
    
    try {
      const { file_url } = await UploadFile({ file });
      const result = await ExtractDataFromUploadedFile({
        file_url: file_url,
        json_schema: WISCONSIN_DATASET_SCHEMA
      });

      if (result.status === 'success' && Array.isArray(result.output)) {
        setExtractedData(result.output);
        setStatus('preview');
      } else {
        throw new Error(result.details || "Failed to extract data from the file. Please ensure it's the correct format.");
      }
    } catch (err) {
      setError(err.message);
      setStatus('idle');
    }
  };

  const handleConfirmImport = async () => {
    setStatus('importing');
    try {
      const patientRecords = extractedData.map(row => ({
        patient_id: `WC-${row.id}`,
        age: 40, // Using a default age
        gender: 'female',
        diagnosis_date: new Date().toISOString().split('T')[0],
        prediction: row.diagnosis === 'M' ? 'malignant' : 'benign',
        status: 'completed',
        notes: 'Imported from Wisconsin Dataset.',
        radius_mean: row.radius_mean,
        texture_mean: row.texture_mean,
        perimeter_mean: row.perimeter_mean,
        area_mean: row.area_mean,
        smoothness_mean: row.smoothness_mean,
        compactness_mean: row.compactness_mean,
        concavity_mean: row.concavity_mean,
        concave_points_mean: row['concave points_mean'],
        symmetry_mean: row.symmetry_mean,
        fractal_dimension_mean: row.fractal_dimension_mean,
      }));

      await Patient.bulkCreate(patientRecords);
      setStatus('success');
    } catch (err) {
      setError("An error occurred while saving the data to the database.");
      setStatus('preview');
    }
  };

  const resetState = () => {
    setFile(null);
    setStatus('idle');
    setError(null);
    setExtractedData([]);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <Button
            variant="outline"
            size="icon"
            onClick={() => navigate(createPageUrl("Dashboard"))}
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-2xl md:text-3xl font-bold text-gray-900">Import Dataset</h1>
            <p className="text-gray-600 mt-1">Upload the Breast Cancer Wisconsin (Diagnostic) dataset.</p>
          </div>
        </div>

        {error && (
          <Alert variant="destructive" className="mb-6">
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {status === 'success' ? (
          <Card className="shadow-lg text-center p-8">
            <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
            <h2 className="text-2xl font-semibold mb-2">Import Successful!</h2>
            <p className="text-gray-600 mb-6">{extractedData.length} records have been added to your patient cases.</p>
            <div className="flex justify-center gap-4">
              <Button variant="outline" onClick={resetState}>Import Another File</Button>
              <Button onClick={() => navigate(createPageUrl("Cases"))}>View Cases</Button>
            </div>
          </Card>
        ) : (
          <Card className="shadow-lg bg-white/80 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="w-5 h-5 text-blue-600" />
                Upload CSV File
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {status === 'idle' && (
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                  <FileUp className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="mb-4 text-gray-600">Select the 'data.csv' file from the Wisconsin dataset.</p>
                  <Input id="csv-upload" type="file" accept=".csv" onChange={handleFileChange} className="max-w-sm mx-auto" />
                  {file && (
                    <Button onClick={handleProcessFile} className="mt-6">
                      Process File
                    </Button>
                  )}
                </div>
              )}

              {(status === 'processing' || status === 'importing') && (
                <div className="text-center p-8">
                  <Loader2 className="w-12 h-12 text-blue-600 mx-auto mb-4 animate-spin" />
                  <h3 className="text-xl font-semibold">
                    {status === 'processing' ? 'Processing File...' : 'Importing Data...'}
                  </h3>
                  <p className="text-gray-500">Please wait a moment.</p>
                </div>
              )}

              {status === 'preview' && (
                <div>
                  <h3 className="font-semibold mb-2">Data Preview ({extractedData.length} records found)</h3>
                  <p className="text-sm text-gray-500 mb-4">Here's a sample of the data extracted from your file. Does this look correct?</p>
                  <div className="max-h-60 overflow-y-auto border rounded-lg">
                    <UiTable>
                      <TableHeader>
                        <TableRow>
                          <TableHead>ID</TableHead>
                          <TableHead>Diagnosis</TableHead>
                          <TableHead>Radius Mean</TableHead>
                          <TableHead>Texture Mean</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {extractedData.slice(0, 5).map((row) => (
                          <TableRow key={row.id}>
                            <TableCell>{row.id}</TableCell>
                            <TableCell>{row.diagnosis === 'M' ? 'Malignant' : 'Benign'}</TableCell>
                            <TableCell>{row.radius_mean.toFixed(2)}</TableCell>
                            <TableCell>{row.texture_mean.toFixed(2)}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </UiTable>
                  </div>
                  <div className="flex justify-end gap-4 mt-6">
                    <Button variant="outline" onClick={resetState}>Cancel</Button>
                    <Button onClick={handleConfirmImport}>Confirm and Import</Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}