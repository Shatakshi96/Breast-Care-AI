import React, { useState } from "react";
import { Patient } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

import PatientInfoForm from "../components/analysis/PatientInfoForm";
import TumorFeaturesForm from "../components/analysis/TumorFeaturesForm";
import PredictionResults from "../components/analysis/PredictionResults";

export default function Analysis() {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(1);
  const [patientData, setPatientData] = useState({});
  const [tumorFeatures, setTumorFeatures] = useState({});
  const [prediction, setPrediction] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);

  const handlePatientSubmit = (data) => {
    setPatientData(data);
    setCurrentStep(2);
  };

  const handleFeaturesSubmit = async (features) => {
    setTumorFeatures(features);
    setIsProcessing(true);
    
    // Simulate ML prediction (in real app, this would call your ML API)
    setTimeout(() => {
      const mockPrediction = {
        prediction: Math.random() > 0.6 ? 'malignant' : 'benign',
        confidence_score: Math.random() * 0.3 + 0.7, // 0.7-1.0
        features_analysis: {
          high_risk_features: ['radius_mean', 'texture_mean'],
          low_risk_features: ['symmetry_mean', 'smoothness_mean']
        }
      };
      
      setPrediction(mockPrediction);
      setIsProcessing(false);
      setCurrentStep(3);
    }, 3000);
  };

  const handleSaveCase = async () => {
    try {
      await Patient.create({
        ...patientData,
        ...tumorFeatures,
        ...prediction
      });
      navigate(createPageUrl("Cases"));
    } catch (error) {
      console.error("Error saving case:", error);
    }
  };

  const steps = [
    { number: 1, title: "Patient Information", active: currentStep === 1, completed: currentStep > 1 },
    { number: 2, title: "Tumor Features", active: currentStep === 2, completed: currentStep > 2 },
    { number: 3, title: "Analysis Results", active: currentStep === 3, completed: false }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <Button
            variant="outline"
            size="icon"
            onClick={() => navigate(createPageUrl("Dashboard"))}
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-2xl md:text-3xl font-bold text-gray-900">New Tumor Analysis</h1>
            <p className="text-gray-600 mt-1">AI-powered breast cancer prediction</p>
          </div>
        </div>

        {/* Progress Steps */}
        <div className="flex justify-center mb-8">
          <div className="flex items-center space-x-4">
            {steps.map((step) => (
              <div key={step.number} className="flex items-center">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold text-sm ${
                  step.completed 
                    ? 'bg-green-500 text-white' 
                    : step.active 
                      ? 'bg-blue-500 text-white' 
                      : 'bg-gray-200 text-gray-500'
                }`}>
                  {step.completed ? '✓' : step.number}
                </div>
                <div className="ml-2 mr-6">
                  <p className={`text-sm font-medium ${
                    step.active ? 'text-blue-600' : step.completed ? 'text-green-600' : 'text-gray-500'
                  }`}>
                    {step.title}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Step Content */}
        {currentStep === 1 && (
          <PatientInfoForm onSubmit={handlePatientSubmit} initialData={patientData} />
        )}

        {currentStep === 2 && (
          <TumorFeaturesForm 
            onSubmit={handleFeaturesSubmit} 
            onBack={() => setCurrentStep(1)}
            initialData={tumorFeatures}
          />
        )}

        {currentStep === 3 && (
          <PredictionResults 
            patientData={patientData}
            prediction={prediction}
            isProcessing={isProcessing}
            onSave={handleSaveCase}
            onBack={() => setCurrentStep(2)}
          />
        )}
      </div>
    </div>
  );
}