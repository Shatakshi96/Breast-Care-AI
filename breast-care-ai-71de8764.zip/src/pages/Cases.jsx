
import React, { useState, useEffect, useCallback } from "react";
import { Patient } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  Search, 
  Filter, 
  ArrowLeft,
  Eye,
  FileText
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format } from "date-fns";

import CaseDetails from "../components/cases/CaseDetails";
import FilterPanel from "../components/cases/FilterPanel";

export default function Cases() {
  const navigate = useNavigate();
  const [patients, setPatients] = useState([]);
  const [filteredPatients, setFilteredPatients] = useState([]);
  const [selectedCase, setSelectedCase] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState({
    prediction: "all",
    status: "all",
    dateRange: "all"
  });
  const [isLoading, setIsLoading] = useState(true);

  const applyFilters = useCallback(() => {
    let filtered = [...patients];

    // Search filter
    if (searchTerm) {
      filtered = filtered.filter(patient => 
        patient.patient_id?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        patient.notes?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Prediction filter
    if (filters.prediction !== "all") {
      filtered = filtered.filter(patient => patient.prediction === filters.prediction);
    }

    // Status filter
    if (filters.status !== "all") {
      filtered = filtered.filter(patient => patient.status === filters.status);
    }

    setFilteredPatients(filtered);
  }, [patients, searchTerm, filters]); // Dependencies for useCallback

  useEffect(() => {
    loadPatients();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [applyFilters]); // Dependency for useEffect

  const loadPatients = async () => {
    setIsLoading(true);
    try {
      const data = await Patient.list("-created_date");
      setPatients(data);
    } catch (error) {
      console.error("Error loading patients:", error);
    }
    setIsLoading(false);
  };

  const getPredictionBadge = (prediction, confidence) => {
    const colors = {
      malignant: "bg-red-100 text-red-800 border-red-200",
      benign: "bg-green-100 text-green-800 border-green-200",
      pending: "bg-yellow-100 text-yellow-800 border-yellow-200"
    };

    return (
      <div className="flex items-center gap-2">
        <Badge className={`${colors[prediction]} border`}>
          {prediction}
        </Badge>
        {confidence && (
          <span className="text-xs text-gray-500">
            {(confidence * 100).toFixed(1)}%
          </span>
        )}
      </div>
    );
  };

  if (selectedCase) {
    return (
      <CaseDetails 
        patient={selectedCase}
        onBack={() => setSelectedCase(null)}
        onRefresh={loadPatients}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <Button
            variant="outline"
            size="icon"
            onClick={() => navigate(createPageUrl("Dashboard"))}
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-2xl md:text-3xl font-bold text-gray-900">Patient Cases</h1>
            <p className="text-gray-600 mt-1">Manage and review tumor analysis cases</p>
          </div>
        </div>

        {/* Search and Filter Bar */}
        <Card className="mb-6 shadow-lg bg-white/80 backdrop-blur-sm">
          <CardContent className="p-4">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  placeholder="Search by patient ID or notes..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Button
                variant="outline"
                onClick={() => setShowFilters(!showFilters)}
                className="flex items-center gap-2"
              >
                <Filter className="w-4 h-4" />
                Filters
              </Button>
            </div>
            
            {showFilters && (
              <FilterPanel 
                filters={filters} 
                onFiltersChange={setFilters}
                className="mt-4 pt-4 border-t"
              />
            )}
          </CardContent>
        </Card>

        {/* Cases List */}
        <Card className="shadow-lg bg-white/80 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-blue-600" />
                Cases ({filteredPatients.length})
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-4">
                {Array(5).fill(0).map((_, i) => (
                  <div key={i} className="animate-pulse">
                    <div className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="space-y-2">
                        <div className="h-4 bg-gray-200 rounded w-24"></div>
                        <div className="h-3 bg-gray-200 rounded w-16"></div>
                      </div>
                      <div className="h-6 bg-gray-200 rounded w-16"></div>
                    </div>
                  </div>
                ))}
              </div>
            ) : filteredPatients.length === 0 ? (
              <div className="text-center py-12">
                <FileText className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-500 mb-2">No cases found</p>
                <p className="text-sm text-gray-400">Try adjusting your search or filters</p>
              </div>
            ) : (
              <div className="space-y-4">
                {filteredPatients.map((patient) => (
                  <div 
                    key={patient.id}
                    className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 cursor-pointer transition-colors"
                    onClick={() => setSelectedCase(patient)}
                  >
                    <div className="flex items-center gap-4">
                      <div>
                        <h3 className="font-semibold">Patient {patient.patient_id}</h3>
                        <p className="text-sm text-gray-500">
                          Age {patient.age} • {format(new Date(patient.diagnosis_date), "MMM d, yyyy")}
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-4">
                      {getPredictionBadge(patient.prediction, patient.confidence_score)}
                      <Button variant="ghost" size="icon">
                        <Eye className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
